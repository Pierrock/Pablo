﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;                //  pour FileInfo
using System.Windows.Forms;     //  pour MessageBox






namespace PABLO
{
    class cls_DXF
    {
        private FileInfo theSourceFile;
        private double _XMax;
        private double _YMax;

        private double _XMin = 999999.99;
        private double _YMin = 999999.99;

        private double _xOld = -1;
        private double _yOld = -1;

        List<cls_vecteur> vecteurs = new List<cls_vecteur>();

        public List<cls_vecteur> Vecteurs
        {
            get { return vecteurs;  }
        }


        public double Xmax
        {
            get { return _XMax; }
        }

        public double Ymax
        {
            get { return _YMax; }
        }

        public double Xmin
        {
            get { return _XMin; }
        }

        public double Ymin
        {
            get { return _YMin; }
        }


        #region Lecture de fichier

        //Reads a text file (in fact a DXF file) for importing an Autocad drawing.
        public bool ReadFromFile(string textFile)
        //In the DXF File structure, data is stored in two-line groupings ( or bi-line, coupling line ...whatever you call it)
        //in this grouping the first line defines the data, the second line contains the data value.
        //..as a result there is always even number of lines in the DXF file..
        {

            vecteurs.Clear();
            _XMax = 0;
            _YMax = 0;
            _XMin = 999999.99;
            _YMin = 999999.99;

            string line1, line2;							//these line1 and line2 is used for getting the a/m data groups...

            line1 = "0";									//line1 and line2 are are initialized here...
            line2 = "0";

            long position = 0;

            theSourceFile = new FileInfo(textFile);		    //  the sourceFile is set.

            StreamReader reader = null;						//  a reader is prepared...

            try
            {
                reader = theSourceFile.OpenText();			//the reader is set ...
            }
            catch (FileNotFoundException e)
            {
                MessageBox.Show(e.FileName.ToString() + "\r cannot be found", "File not found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            catch
            {
                MessageBox.Show("An error occured while opening the DXF file","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            do
            {

            //  This part interpretes the drawing objects found in the DXF file...
                if (line1 == "0" && line2 == "LINE") LineModule(reader);

                GetLineCouple(reader, out line1, out line2);		//the related method is called for iterating through the text file and assigning values to line1 and line2...

            }
            while (line2 != "EOF");

            reader.DiscardBufferedData();							//reader is cleared...
            theSourceFile = null;

            reader.Close();                                         //...and closed.


            //  on peut centrer toutes les coordonnées contenues dans vecteurs

             
            //  le centre des vecteurs
            double largeurDXF = _XMax - _XMin;
            double hauteurDXF = _YMax - _YMin;

            double XcentreDXF = largeurDXF / 2;
            double YcentreDXF = hauteurDXF / 2;

            double Xdeltat = XcentreDXF + _XMin;
            double Ydeltat = YcentreDXF + _YMin;

            _XMax = 0;
            _YMax = 0;
            _XMin = 999999.99;
            _YMin = 999999.99;

            for (int I = 0; I < vecteurs.Count; I++)
            {
                vecteurs[I].x1 = vecteurs[I].x1 - Xdeltat;
                vecteurs[I].y1 = vecteurs[I].y1 - Ydeltat;

                vecteurs[I].x2 = vecteurs[I].x2 - Xdeltat;
                vecteurs[I].y2 = vecteurs[I].y2 - Ydeltat;


                if (vecteurs[I].x1 > _XMax) _XMax = vecteurs[I].x1;
                if (vecteurs[I].x1 < _XMin) _XMin = vecteurs[I].x1;

                if (vecteurs[I].y1 > _YMax) _YMax = vecteurs[I].y1;
                if (vecteurs[I].y1 < _YMin) _YMin = vecteurs[I].y1;


                if (vecteurs[I].x2 > _XMax) _XMax = vecteurs[I].x2;
                if (vecteurs[I].x2 < _XMin) _XMin = vecteurs[I].x2;

                if (vecteurs[I].y2 > _YMax) _YMax = vecteurs[I].y2;
                if (vecteurs[I].y2 < _YMin) _YMin = vecteurs[I].y2;
            }
            return true;
        }

        private void GetLineCouple(StreamReader theReader, out string line1, out string line2)		//this method is used to iterate through the text file and assign values to line1 and line2
        {
            System.Globalization.CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
            string decimalSeparator = ci.NumberFormat.CurrencyDecimalSeparator;

            line1 = line2 = "";

            if (theReader == null)
                return;

            line1 = theReader.ReadLine();
            if (line1 != null)
            {
                line1 = line1.Trim();
                line1 = line1.Replace('.', decimalSeparator[0]);

            }
            line2 = theReader.ReadLine();
            if (line2 != null)
            {
                line2 = line2.Trim();
                line2 = line2.Replace('.', decimalSeparator[0]);
            }

        }

        private void LineModule(StreamReader reader)		//Interpretes line objects in the DXF file
        {
            string line1, line2;
            line1 = "0";
            line2 = "0";

            double x1 = 0;
            double y1 = 0;
            double x2 = 0;
            double y2 = 0;


            //  0
            //  LINE
            //  8
            //  Layer 1
            //  10
            //  216.416526
            //  20
            //  184.773900
            //  11
            //  214.282220
            //  21
            //  184.632789

            do
            {
                GetLineCouple(reader, out line1, out line2);

                if (line1 == "10")                      //  Start point X
                {
                    x1 = Convert.ToDouble(line2);
                    if (x1 > _XMax)  _XMax = x1;
                    if (x1 < _XMin)  _XMin = x1;
                }

                if (line1 == "20")                      //  Start point Y
                {
                    y1 = Convert.ToDouble(line2);
                    if (y1 > _YMax)  _YMax = y1;
                    if (y1 < _YMin)  _YMin = y1;
                }

                if (line1 == "11")                      //  End point X
                {
                    x2 = Convert.ToDouble(line2);
                    if (x2 > _XMax)  _XMax = x2;
                    if (x2 < _XMin)  _XMin = x2;
                }

                if (line1 == "21")                      //  End point Y
                {
                    y2 = Convert.ToDouble(line2);
                    if (y2 > _YMax)  _YMax = y2;
                    if (y2 < _YMin)  _YMin = y2;
                }
            }
            while (line1 != "21");
             
            vecteurs.Add(  new cls_vecteur { x1 = x1, y1 = y1, x2 = x2, y2 = y2 } );

        }

        #endregion

    }
}
