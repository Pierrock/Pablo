﻿namespace PABLO
{
    partial class frm_main
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_main));
            this.gmap = new GMap.NET.WindowsForms.GMapControl();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Grid = new System.Windows.Forms.DataGridView();
            this.Track = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Y1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.outil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Y = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dist = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Scrl_Diviseur = new System.Windows.Forms.VScrollBar();
            this.lbl_Diviseur = new System.Windows.Forms.Label();
            this.Scrl_Rotation = new System.Windows.Forms.VScrollBar();
            this.lbl_Rotation = new System.Windows.Forms.Label();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.lbl_DXFlargeur = new System.Windows.Forms.Label();
            this.lbl_DXFhauteur = new System.Windows.Forms.Label();
            this.lbl_overlays = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_DXFlargeurMin = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_DXFlargeurMax = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_DXFhauteurMax = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_DXFhauteurMin = new System.Windows.Forms.Label();
            this.btn_OutNMEA = new System.Windows.Forms.Button();
            this.lbl_track_01 = new System.Windows.Forms.Label();
            this.lbl_track_from = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_track_to = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_track_name = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_track_points = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_track_distance = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_Regen = new System.Windows.Forms.Button();
            this.btn_try1 = new System.Windows.Forms.Button();
            this.lbl_track_distance2 = new System.Windows.Forms.Label();
            this.btn_Excentrer = new System.Windows.Forms.Button();
            this.chk_centerLeft = new System.Windows.Forms.CheckBox();
            this.chk_centerRight = new System.Windows.Forms.CheckBox();
            this.chk_centerTop = new System.Windows.Forms.CheckBox();
            this.chk_centerBottom = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gmap
            // 
            this.gmap.Bearing = 0F;
            this.gmap.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gmap.CanDragMap = true;
            this.gmap.Cursor = System.Windows.Forms.Cursors.Cross;
            this.gmap.EmptyTileColor = System.Drawing.Color.Navy;
            this.gmap.GrayScaleMode = false;
            this.gmap.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gmap.LevelsKeepInMemmory = 5;
            this.gmap.Location = new System.Drawing.Point(15, 50);
            this.gmap.MarkersEnabled = true;
            this.gmap.MaxZoom = 18;
            this.gmap.MinZoom = 2;
            this.gmap.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gmap.Name = "gmap";
            this.gmap.NegativeMode = false;
            this.gmap.PolygonsEnabled = true;
            this.gmap.RetryLoadTile = 0;
            this.gmap.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gmap.RoutesEnabled = true;
            this.gmap.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gmap.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gmap.ShowTileGridLines = false;
            this.gmap.Size = new System.Drawing.Size(508, 472);
            this.gmap.TabIndex = 48;
            this.gmap.Zoom = 5D;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(348, 20);
            this.textBox1.TabIndex = 49;
            // 
            // Grid
            // 
            this.Grid.AllowUserToAddRows = false;
            this.Grid.AllowUserToDeleteRows = false;
            this.Grid.AllowUserToResizeRows = false;
            this.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Track,
            this.X1,
            this.Y1,
            this.outil,
            this.Y,
            this.X,
            this.Dist});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Grid.DefaultCellStyle = dataGridViewCellStyle1;
            this.Grid.Location = new System.Drawing.Point(626, 27);
            this.Grid.Name = "Grid";
            this.Grid.ReadOnly = true;
            this.Grid.RowHeadersWidth = 20;
            this.Grid.Size = new System.Drawing.Size(580, 680);
            this.Grid.TabIndex = 56;
            // 
            // Track
            // 
            this.Track.HeaderText = "tr";
            this.Track.Name = "Track";
            this.Track.ReadOnly = true;
            this.Track.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Track.Width = 30;
            // 
            // X1
            // 
            this.X1.HeaderText = "latitude";
            this.X1.Name = "X1";
            this.X1.ReadOnly = true;
            this.X1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.X1.Width = 90;
            // 
            // Y1
            // 
            this.Y1.HeaderText = "longitude";
            this.Y1.Name = "Y1";
            this.Y1.ReadOnly = true;
            this.Y1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // outil
            // 
            this.outil.HeaderText = "outil";
            this.outil.Name = "outil";
            this.outil.ReadOnly = true;
            this.outil.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.outil.Width = 50;
            // 
            // Y
            // 
            this.Y.HeaderText = "Y";
            this.Y.Name = "Y";
            this.Y.ReadOnly = true;
            this.Y.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Y.Width = 80;
            // 
            // X
            // 
            this.X.HeaderText = "X";
            this.X.Name = "X";
            this.X.ReadOnly = true;
            this.X.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.X.Width = 80;
            // 
            // Dist
            // 
            this.Dist.HeaderText = "Distance";
            this.Dist.Name = "Dist";
            this.Dist.ReadOnly = true;
            this.Dist.Width = 60;
            // 
            // Scrl_Diviseur
            // 
            this.Scrl_Diviseur.Location = new System.Drawing.Point(546, 172);
            this.Scrl_Diviseur.Maximum = 30000;
            this.Scrl_Diviseur.Minimum = 1;
            this.Scrl_Diviseur.Name = "Scrl_Diviseur";
            this.Scrl_Diviseur.Size = new System.Drawing.Size(17, 350);
            this.Scrl_Diviseur.TabIndex = 57;
            this.Scrl_Diviseur.Value = 1;
            this.Scrl_Diviseur.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Scrl_Diviseur_Scroll);
            // 
            // lbl_Diviseur
            // 
            this.lbl_Diviseur.AutoSize = true;
            this.lbl_Diviseur.Location = new System.Drawing.Point(533, 144);
            this.lbl_Diviseur.Name = "lbl_Diviseur";
            this.lbl_Diviseur.Size = new System.Drawing.Size(43, 13);
            this.lbl_Diviseur.TabIndex = 58;
            this.lbl_Diviseur.Text = "diviseur";
            // 
            // Scrl_Rotation
            // 
            this.Scrl_Rotation.Location = new System.Drawing.Point(594, 172);
            this.Scrl_Rotation.Maximum = 369;
            this.Scrl_Rotation.Name = "Scrl_Rotation";
            this.Scrl_Rotation.Size = new System.Drawing.Size(17, 350);
            this.Scrl_Rotation.TabIndex = 59;
            this.Scrl_Rotation.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Scrl_Rotation_Scroll);
            // 
            // lbl_Rotation
            // 
            this.lbl_Rotation.AutoSize = true;
            this.lbl_Rotation.Location = new System.Drawing.Point(591, 144);
            this.lbl_Rotation.Name = "lbl_Rotation";
            this.lbl_Rotation.Size = new System.Drawing.Size(29, 13);
            this.lbl_Rotation.TabIndex = 60;
            this.lbl_Rotation.Text = "000°";
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(536, 27);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(75, 23);
            this.btn_Clear.TabIndex = 61;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // lbl_DXFlargeur
            // 
            this.lbl_DXFlargeur.AutoSize = true;
            this.lbl_DXFlargeur.Location = new System.Drawing.Point(84, 639);
            this.lbl_DXFlargeur.Name = "lbl_DXFlargeur";
            this.lbl_DXFlargeur.Size = new System.Drawing.Size(40, 13);
            this.lbl_DXFlargeur.TabIndex = 62;
            this.lbl_DXFlargeur.Text = "00.000";
            // 
            // lbl_DXFhauteur
            // 
            this.lbl_DXFhauteur.AutoSize = true;
            this.lbl_DXFhauteur.Location = new System.Drawing.Point(84, 657);
            this.lbl_DXFhauteur.Name = "lbl_DXFhauteur";
            this.lbl_DXFhauteur.Size = new System.Drawing.Size(40, 13);
            this.lbl_DXFhauteur.TabIndex = 63;
            this.lbl_DXFhauteur.Text = "00.000";
            // 
            // lbl_overlays
            // 
            this.lbl_overlays.AutoSize = true;
            this.lbl_overlays.Location = new System.Drawing.Point(84, 687);
            this.lbl_overlays.Name = "lbl_overlays";
            this.lbl_overlays.Size = new System.Drawing.Size(37, 13);
            this.lbl_overlays.TabIndex = 64;
            this.lbl_overlays.Text = "00000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 687);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 65;
            this.label1.Text = "tracks :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 639);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 66;
            this.label2.Text = "dxf width :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 657);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 67;
            this.label3.Text = "dxf height :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 639);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 69;
            this.label4.Text = "min :";
            // 
            // lbl_DXFlargeurMin
            // 
            this.lbl_DXFlargeurMin.AutoSize = true;
            this.lbl_DXFlargeurMin.Location = new System.Drawing.Point(176, 639);
            this.lbl_DXFlargeurMin.Name = "lbl_DXFlargeurMin";
            this.lbl_DXFlargeurMin.Size = new System.Drawing.Size(40, 13);
            this.lbl_DXFlargeurMin.TabIndex = 68;
            this.lbl_DXFlargeurMin.Text = "00.000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(237, 639);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 71;
            this.label6.Text = "max :";
            // 
            // lbl_DXFlargeurMax
            // 
            this.lbl_DXFlargeurMax.AutoSize = true;
            this.lbl_DXFlargeurMax.Location = new System.Drawing.Point(275, 639);
            this.lbl_DXFlargeurMax.Name = "lbl_DXFlargeurMax";
            this.lbl_DXFlargeurMax.Size = new System.Drawing.Size(40, 13);
            this.lbl_DXFlargeurMax.TabIndex = 70;
            this.lbl_DXFlargeurMax.Text = "00.000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(237, 657);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 75;
            this.label5.Text = "max :";
            // 
            // lbl_DXFhauteurMax
            // 
            this.lbl_DXFhauteurMax.AutoSize = true;
            this.lbl_DXFhauteurMax.Location = new System.Drawing.Point(275, 657);
            this.lbl_DXFhauteurMax.Name = "lbl_DXFhauteurMax";
            this.lbl_DXFhauteurMax.Size = new System.Drawing.Size(40, 13);
            this.lbl_DXFhauteurMax.TabIndex = 74;
            this.lbl_DXFhauteurMax.Text = "00.000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(141, 657);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 73;
            this.label8.Text = "min :";
            // 
            // lbl_DXFhauteurMin
            // 
            this.lbl_DXFhauteurMin.AutoSize = true;
            this.lbl_DXFhauteurMin.Location = new System.Drawing.Point(176, 657);
            this.lbl_DXFhauteurMin.Name = "lbl_DXFhauteurMin";
            this.lbl_DXFhauteurMin.Size = new System.Drawing.Size(40, 13);
            this.lbl_DXFhauteurMin.TabIndex = 72;
            this.lbl_DXFhauteurMin.Text = "00.000";
            // 
            // btn_OutNMEA
            // 
            this.btn_OutNMEA.Location = new System.Drawing.Point(503, 667);
            this.btn_OutNMEA.Name = "btn_OutNMEA";
            this.btn_OutNMEA.Size = new System.Drawing.Size(117, 23);
            this.btn_OutNMEA.TabIndex = 76;
            this.btn_OutNMEA.Text = "generate KML";
            this.btn_OutNMEA.UseVisualStyleBackColor = true;
            this.btn_OutNMEA.Click += new System.EventHandler(this.btn_OutTrames_Click);
            // 
            // lbl_track_01
            // 
            this.lbl_track_01.Location = new System.Drawing.Point(16, 566);
            this.lbl_track_01.Name = "lbl_track_01";
            this.lbl_track_01.Size = new System.Drawing.Size(55, 13);
            this.lbl_track_01.TabIndex = 78;
            this.lbl_track_01.Text = "from :";
            // 
            // lbl_track_from
            // 
            this.lbl_track_from.Location = new System.Drawing.Point(88, 566);
            this.lbl_track_from.Name = "lbl_track_from";
            this.lbl_track_from.Size = new System.Drawing.Size(109, 13);
            this.lbl_track_from.TabIndex = 77;
            this.lbl_track_from.Text = "-00.00000000";
            this.lbl_track_from.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(16, 579);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 80;
            this.label7.Text = "to :";
            // 
            // lbl_track_to
            // 
            this.lbl_track_to.Location = new System.Drawing.Point(88, 579);
            this.lbl_track_to.Name = "lbl_track_to";
            this.lbl_track_to.Size = new System.Drawing.Size(109, 13);
            this.lbl_track_to.TabIndex = 79;
            this.lbl_track_to.Text = "-00.00000000";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(16, 540);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 82;
            this.label9.Text = "name :";
            // 
            // lbl_track_name
            // 
            this.lbl_track_name.Location = new System.Drawing.Point(88, 540);
            this.lbl_track_name.Name = "lbl_track_name";
            this.lbl_track_name.Size = new System.Drawing.Size(128, 13);
            this.lbl_track_name.TabIndex = 81;
            this.lbl_track_name.Text = "track name";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(16, 592);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 84;
            this.label10.Text = "points :";
            // 
            // lbl_track_points
            // 
            this.lbl_track_points.Location = new System.Drawing.Point(88, 592);
            this.lbl_track_points.Name = "lbl_track_points";
            this.lbl_track_points.Size = new System.Drawing.Size(82, 13);
            this.lbl_track_points.TabIndex = 83;
            this.lbl_track_points.Text = "999";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(16, 605);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 13);
            this.label11.TabIndex = 86;
            this.label11.Text = "distance :";
            // 
            // lbl_track_distance
            // 
            this.lbl_track_distance.Location = new System.Drawing.Point(88, 605);
            this.lbl_track_distance.Name = "lbl_track_distance";
            this.lbl_track_distance.Size = new System.Drawing.Size(82, 13);
            this.lbl_track_distance.TabIndex = 85;
            this.lbl_track_distance.Text = "999";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1202, 24);
            this.menuStrip1.TabIndex = 87;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // btn_Regen
            // 
            this.btn_Regen.Enabled = false;
            this.btn_Regen.Location = new System.Drawing.Point(536, 56);
            this.btn_Regen.Name = "btn_Regen";
            this.btn_Regen.Size = new System.Drawing.Size(75, 23);
            this.btn_Regen.TabIndex = 88;
            this.btn_Regen.Text = "Regen";
            this.btn_Regen.UseVisualStyleBackColor = true;
            this.btn_Regen.Click += new System.EventHandler(this.btn_Regen_Click);
            // 
            // btn_try1
            // 
            this.btn_try1.Location = new System.Drawing.Point(503, 605);
            this.btn_try1.Name = "btn_try1";
            this.btn_try1.Size = new System.Drawing.Size(75, 23);
            this.btn_try1.TabIndex = 89;
            this.btn_try1.Text = "try";
            this.btn_try1.UseVisualStyleBackColor = true;
            this.btn_try1.Click += new System.EventHandler(this.btn_try1_Click);
            // 
            // lbl_track_distance2
            // 
            this.lbl_track_distance2.Location = new System.Drawing.Point(511, 540);
            this.lbl_track_distance2.Name = "lbl_track_distance2";
            this.lbl_track_distance2.Size = new System.Drawing.Size(100, 13);
            this.lbl_track_distance2.TabIndex = 90;
            this.lbl_track_distance2.Text = "distance";
            // 
            // btn_Excentrer
            // 
            this.btn_Excentrer.Location = new System.Drawing.Point(536, 104);
            this.btn_Excentrer.Name = "btn_Excentrer";
            this.btn_Excentrer.Size = new System.Drawing.Size(75, 23);
            this.btn_Excentrer.TabIndex = 91;
            this.btn_Excentrer.Text = "Excentrer";
            this.btn_Excentrer.UseVisualStyleBackColor = true;
            this.btn_Excentrer.Click += new System.EventHandler(this.btn_Excentrer_Click);
            // 
            // chk_centerLeft
            // 
            this.chk_centerLeft.AutoSize = true;
            this.chk_centerLeft.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chk_centerLeft.Location = new System.Drawing.Point(335, 575);
            this.chk_centerLeft.Name = "chk_centerLeft";
            this.chk_centerLeft.Size = new System.Drawing.Size(44, 17);
            this.chk_centerLeft.TabIndex = 92;
            this.chk_centerLeft.Text = "Left";
            this.chk_centerLeft.UseVisualStyleBackColor = true;
            // 
            // chk_centerRight
            // 
            this.chk_centerRight.AutoSize = true;
            this.chk_centerRight.Location = new System.Drawing.Point(429, 579);
            this.chk_centerRight.Name = "chk_centerRight";
            this.chk_centerRight.Size = new System.Drawing.Size(51, 17);
            this.chk_centerRight.TabIndex = 93;
            this.chk_centerRight.Text = "Right";
            this.chk_centerRight.UseVisualStyleBackColor = true;
            // 
            // chk_centerTop
            // 
            this.chk_centerTop.AutoSize = true;
            this.chk_centerTop.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.chk_centerTop.Location = new System.Drawing.Point(388, 536);
            this.chk_centerTop.Name = "chk_centerTop";
            this.chk_centerTop.Size = new System.Drawing.Size(30, 31);
            this.chk_centerTop.TabIndex = 94;
            this.chk_centerTop.Text = "Top";
            this.chk_centerTop.UseVisualStyleBackColor = true;
            // 
            // chk_centerBottom
            // 
            this.chk_centerBottom.AutoSize = true;
            this.chk_centerBottom.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.chk_centerBottom.Location = new System.Drawing.Point(379, 601);
            this.chk_centerBottom.Name = "chk_centerBottom";
            this.chk_centerBottom.Size = new System.Drawing.Size(44, 31);
            this.chk_centerBottom.TabIndex = 95;
            this.chk_centerBottom.Text = "Bottom";
            this.chk_centerBottom.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(385, 579);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 96;
            this.label12.Text = "Center";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1202, 702);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.chk_centerBottom);
            this.Controls.Add(this.chk_centerTop);
            this.Controls.Add(this.chk_centerRight);
            this.Controls.Add(this.chk_centerLeft);
            this.Controls.Add(this.btn_Excentrer);
            this.Controls.Add(this.lbl_track_distance2);
            this.Controls.Add(this.btn_try1);
            this.Controls.Add(this.btn_Regen);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lbl_track_distance);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lbl_track_points);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbl_track_name);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_track_to);
            this.Controls.Add(this.lbl_track_01);
            this.Controls.Add(this.lbl_track_from);
            this.Controls.Add(this.btn_OutNMEA);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl_DXFhauteurMax);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl_DXFhauteurMin);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_DXFlargeurMax);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbl_DXFlargeurMin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_overlays);
            this.Controls.Add(this.lbl_DXFhauteur);
            this.Controls.Add(this.lbl_DXFlargeur);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.lbl_Rotation);
            this.Controls.Add(this.Scrl_Rotation);
            this.Controls.Add(this.lbl_Diviseur);
            this.Controls.Add(this.Scrl_Diviseur);
            this.Controls.Add(this.Grid);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.gmap);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm_main";
            this.Text = "Mission";
            this.Load += new System.EventHandler(this.frm_main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Grid)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GMap.NET.WindowsForms.GMapControl gmap;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView Grid;
        private System.Windows.Forms.VScrollBar Scrl_Diviseur;
        private System.Windows.Forms.Label lbl_Diviseur;
        private System.Windows.Forms.VScrollBar Scrl_Rotation;
        private System.Windows.Forms.Label lbl_Rotation;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Label lbl_DXFlargeur;
        private System.Windows.Forms.Label lbl_DXFhauteur;
        private System.Windows.Forms.Label lbl_overlays;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_DXFlargeurMin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_DXFlargeurMax;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_DXFhauteurMax;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_DXFhauteurMin;
        private System.Windows.Forms.Button btn_OutNMEA;
        private System.Windows.Forms.Label lbl_track_01;
        private System.Windows.Forms.Label lbl_track_from;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_track_to;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_track_name;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_track_points;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_track_distance;
        private System.Windows.Forms.DataGridViewTextBoxColumn Track;
        private System.Windows.Forms.DataGridViewTextBoxColumn X1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y1;
        private System.Windows.Forms.DataGridViewTextBoxColumn outil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y;
        private System.Windows.Forms.DataGridViewTextBoxColumn X;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dist;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.Button btn_Regen;
        private System.Windows.Forms.Button btn_try1;
        private System.Windows.Forms.Label lbl_track_distance2;
        private System.Windows.Forms.Button btn_Excentrer;
        private System.Windows.Forms.CheckBox chk_centerLeft;
        private System.Windows.Forms.CheckBox chk_centerRight;
        private System.Windows.Forms.CheckBox chk_centerTop;
        private System.Windows.Forms.CheckBox chk_centerBottom;
        private System.Windows.Forms.Label label12;
    }
}

