﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Windows.Forms;
using System.IO;

using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;


namespace PABLO
{
    public partial class frm_main : Form
    {
        private Double _CentreLatitude;
        private Double _CentreLongitude;

        private Double _DessinCentreLatitude;
        private Double _DessinCentreLongitude;


        int diviseur = 100000;
        int angle = 0;

        cls_DXF DXF = new cls_DXF();

        GMapRoute currentRoute = null;

        string sFileName;


        public frm_main()
        {
            InitializeComponent();

        }

        private void frm_main_Load(object sender, EventArgs e)
        {
            this.Text = Application.ProductName;
            this.Text += " V" + Application.ProductVersion.ToString();

            // Initialize map:
            gmap.MapProvider = GMap.NET.MapProviders.BingSatelliteMapProvider.Instance;
         // BingMapProvider
         // GoogleSatelliteMapProvider
         // OpenStreetMapProvider

            GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerAndCache;

            gmap.MaxZoom = 24;
            gmap.Zoom =  18;

            // the overlay is created. You can give it a name (optionally), which you can use elsewhere to refer to it (or you could just keep a reference to the overlay instance)
            GMapOverlay markersOverlay = new GMapOverlay("mymarkers");

            // Next, an instance of GMarkerGoogle is created. It takes two arguments: a location (a PointLatLng instance) and a marker type.
            //  {Lat=48,4422267758268, Lng=-2,07408785820007}
            GMarkerGoogle mymarker1 = new GMarkerGoogle(new PointLatLng(48.442226, -2.074087), GMarkerGoogleType.green);

            //{Lat=48,4419954649795, Lng=-2,07414150238037}
            GMarkerGoogle mymarker2 = new GMarkerGoogle(new PointLatLng(48.441995, -2.074141), GMarkerGoogleType.blue);

            // you can create additional markers and add them to your overlay. There’s no limit, except in performance. More markers mean that performance goes down.
            markersOverlay.Markers.Add(mymarker1);
            markersOverlay.Markers.Add(mymarker2);

            gmap.Overlays.Add(markersOverlay);
  
            //  gmap.Position = new GMap.NET.PointLatLng(48.445771, -2.085257);
            
            gmap.Position = new GMap.NET.PointLatLng(48.6369287, -2.1220136);       //  plage

            _CentreLatitude = gmap.Position.Lat;
            _CentreLongitude = gmap.Position.Lng;


            // map events
            gmap.OnPositionChanged += new PositionChanged(gMap_OnCurrentPositionChanged);

            gmap.OnRouteEnter += new RouteEnter(gMap_OnRouteEnter);

            gmap.OnMarkerClick += new MarkerClick(gMap_OnMarkerClick);

        //    Grid.RowEnter += new DataGridViewCellEventHandler(Grid_RowEnter);



        }

        #region events

        private void gMap_OnRouteEnter(GMapRoute item)
        {
            currentRoute = item;

            lbl_track_name.Text = currentRoute.Name;

            string value = "Lat=";
            value += currentRoute.From.Value.Lat.ToString("+0.0000000;-0.0000000");
            value += " Lng=";
            value += currentRoute.From.Value.Lng.ToString("+0.0000000;-0.0000000");
            lbl_track_from.Text = value;

            value = "Lat=";
            value += currentRoute.To.Value.Lat.ToString("00.0000000");
            value += " Lng=";
            value += currentRoute.To.Value.Lng.ToString("00.0000000");
            lbl_track_to.Text = value;
            lbl_track_points.Text = currentRoute.Points.Count.ToString();

            double trackDistance = Convert.ToDouble(currentRoute.Distance);
            trackDistance = trackDistance * 1000;   //  km -> m
            lbl_track_distance.Text = trackDistance.ToString("0.00 m");
        }

        private void gMap_OnMarkerClick(GMapMarker item, MouseEventArgs e)
        {
           // MessageBox.Show(item.Tag + " ", "Collision parameters");
        }

        private void gMap_OnCurrentPositionChanged(PointLatLng point)
        {
            textBox1.Text = "Lat=" + point.Lat.ToString("+0.0000000;-0.0000000") + " Lng=" + point.Lng.ToString("+0.0000000;-0.0000000");
            _CentreLatitude = point.Lat;
            _CentreLongitude = point.Lng;
        }

        #endregion

        #region menu

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofdlog = new OpenFileDialog();
            ofdlog.Filter = "All Files (*.dxf)|*.dxf";
            ofdlog.FilterIndex = 1;
            ofdlog.Multiselect = false;

            if (ofdlog.ShowDialog() == DialogResult.OK)
            {
                sFileName = ofdlog.FileName;

                Grid.RowEnter -= new DataGridViewCellEventHandler(Grid_RowEnter);

                OpenFileDXF(sFileName);

                DrawDXF();

                btn_Regen.Enabled = true;

                Grid.RowEnter += new DataGridViewCellEventHandler(Grid_RowEnter);

            }
        }

        private bool OpenFileDXF(string DXFfile)
        {
            Grid.Rows.Clear();
            gmap.Overlays.Clear();
            gmap.Refresh();
            Application.DoEvents();

            bool readfile;

            readfile = DXF.ReadFromFile(DXFfile);

            return readfile;
        }

        private void DrawDXF()
        {
            GMapOverlay MapOverlay = new GMapOverlay("MyMapOverlay");     // Constructing object for Overlay

            List<PointLatLng> chemin = new List<PointLatLng>(); // The list of Coordinates to be plotted

            chemin.Clear();
            Grid.Rows.Clear();
            gmap.Overlays.Clear();
            gmap.Refresh();

            Application.DoEvents();

            double XcentreMap;
            double YcentreMap;

            XcentreMap = _CentreLongitude;
            YcentreMap = _CentreLatitude;

            _DessinCentreLatitude = YcentreMap;
            _DessinCentreLongitude = XcentreMap;


        //  le centre des vecteurs
            double largeurDXF = DXF.Xmax - DXF.Xmin;
            double hauteurDXF = DXF.Ymax - DXF.Ymin;

            lbl_DXFlargeur.Text = largeurDXF.ToString("0.000");
            lbl_DXFhauteur.Text = hauteurDXF.ToString("0.000");

            lbl_DXFlargeurMin.Text = DXF.Xmin.ToString("0.000");
            lbl_DXFlargeurMax.Text = DXF.Xmax.ToString("0.000");

            lbl_DXFhauteurMin.Text = DXF.Ymin.ToString("0.000");
            lbl_DXFhauteurMax.Text = DXF.Ymax.ToString("0.000");

            double XcentreDXF = largeurDXF / 2;
            double YcentreDXF = hauteurDXF / 2;

            double X1_dxf;
            double Y1_dxf;
            double X2_dxf;
            double Y2_dxf;

            double Xgeographic;     //  les coordonnées exactes 
            double Ygeographic;

            double Xtrack;          //  les coordonnées "zéro"
            double Ytrack;

            double prevLong = 0;
            double prevLat = 0;

            int NbrTrack = 0;

            //  le centre sur la carte
            Xgeographic = XcentreMap + ((0 - XcentreDXF - DXF.Xmin) / diviseur);
            Ygeographic = YcentreMap + ((0 - YcentreDXF - DXF.Ymin) / diviseur);

            // marqueur : centre
            GMarkerGoogle mymarker1 = new GMarkerGoogle(new PointLatLng(Ygeographic, Xgeographic), GMarkerGoogleType.black_small);
            mymarker1.ToolTipText = "Center point";
            MapOverlay.Markers.Add(mymarker1);

            //  toute première coordonnée X
            X1_dxf = DXF.Vecteurs[0].x1;
            Y1_dxf = DXF.Vecteurs[0].y1;

            //  centrage
            if (chk_centerLeft.Checked)     X1_dxf -= DXF.Xmin; //  à gauche = soustrait la plus faible valeur X
            if (chk_centerRight.Checked)    X1_dxf -= DXF.Xmax; //  à droite = soustrait la plus forte valeur X

            if (chk_centerTop.Checked)      Y1_dxf -= DXF.Ymin; //  en haut = soustrait la plus faible valeur Y
            if (chk_centerBottom.Checked)   Y1_dxf -= DXF.Ymax; //  en bas = soustrait la plus forte valeur Y


            Rotate(X1_dxf, Y1_dxf, angle, out X1_dxf, out Y1_dxf);

            //  toute première coordonnée Y
            X2_dxf = DXF.Vecteurs[0].x2;
            Y2_dxf = DXF.Vecteurs[0].y2;

            //  centrage
            if (chk_centerLeft.Checked)     X2_dxf -= DXF.Xmin; //  à gauche = soustrait la plus faible valeur X
            if (chk_centerRight.Checked)    X2_dxf -= DXF.Xmax; //  à droite = soustrait la plus forte valeur X

            if (chk_centerTop.Checked)      Y2_dxf -= DXF.Ymin; //  en haut = soustrait la plus faible valeur Y
            if (chk_centerBottom.Checked)   Y2_dxf -= DXF.Ymax; //  en bas = soustrait la plus forte valeur Y

            Rotate(X2_dxf, Y2_dxf, angle, out X2_dxf, out Y2_dxf);

            NbrTrack++;

            //  les coordonnées géographiques sur la carte
            Xgeographic = XcentreMap + ((X1_dxf - XcentreDXF - DXF.Xmin) / diviseur);
            Ygeographic = YcentreMap + ((Y1_dxf - YcentreDXF - DXF.Ymin) / diviseur);

            chemin.Add(new PointLatLng(Ygeographic, Xgeographic));

            // marqueur : start
            mymarker1 = new GMarkerGoogle(new PointLatLng(Ygeographic, Xgeographic), GMarkerGoogleType.green_big_go);
            string myText = "First track ";
            myText += NbrTrack.ToString();
            myText += " lat ";
            myText += Ygeographic.ToString("0.0000000");
            myText += " long ";
            myText += Xgeographic.ToString("0.0000000");

            mymarker1.ToolTipText = myText;

            MapOverlay.Markers.Add(mymarker1);


            //  les coordonnées pour pablo
            Xtrack = (X1_dxf - XcentreDXF - DXF.Xmin) / diviseur;
            Ytrack = (Y1_dxf - YcentreDXF - DXF.Ymin) / diviseur;

            Grid.Rows.Add(NbrTrack.ToString("0"), Math.Round(Ygeographic, 8).ToString("0.0000000"), Math.Round(Xgeographic, 8).ToString("0.0000000"), false, Math.Round(Ytrack, 8).ToString("+0.0000000;-0.0000000"), Math.Round(Xtrack, 8).ToString("+0.0000000;-0.0000000"));
            Grid.Rows[Grid.RowCount - 1].DefaultCellStyle.BackColor = Color.DarkGray;
            Application.DoEvents();

            prevLong = Xgeographic; //  pour le prochain calcul de la distance
            prevLat = Ygeographic;


            //  les coordonnées géographiques sur la carte
            Xgeographic = XcentreMap + ((X2_dxf - XcentreDXF - DXF.Xmin) / diviseur);
            Ygeographic = YcentreMap + ((Y2_dxf - YcentreDXF - DXF.Ymin) / diviseur);

            //  les coordonnées pour pablo
            Xtrack = (X2_dxf - XcentreDXF - DXF.Xmin) / diviseur;
            Ytrack = (Y2_dxf - YcentreDXF - DXF.Ymin) / diviseur;

            chemin.Add(new PointLatLng(Ygeographic, Xgeographic));

            // distance ?
            double dnewdistance = EarthDistanceCalc(prevLong, prevLat, Xgeographic, Ygeographic);

            Grid.Rows.Add(NbrTrack.ToString("0"), Math.Round(Ygeographic, 8).ToString("0.0000000"), Math.Round(Xgeographic, 8).ToString("0.0000000"), true, Math.Round(Ytrack, 8).ToString("+0.0000000;-0.0000000"), Math.Round(Xtrack, 8).ToString("+0.0000000;-0.0000000"), dnewdistance.ToString("##0.00"));

            prevLong = Xgeographic; //  pour le prochain calcul de la distance
            prevLat = Ygeographic;

            //  les coordonnées suivantes
            for (int i = 1; i < DXF.Vecteurs.Count; i++)
            {

                //  début du segment
                X1_dxf = DXF.Vecteurs[i].x1;
                Y1_dxf = DXF.Vecteurs[i].y1;

                //  centrage
                if (chk_centerLeft.Checked)     X1_dxf -= DXF.Xmin; //  à gauche = soustrait la plus faible valeur X
                if (chk_centerRight.Checked)    X1_dxf -= DXF.Xmax; //  à droite = soustrait la plus forte valeur X

                if (chk_centerTop.Checked)      Y1_dxf -= DXF.Ymin; //  en haut = soustrait la plus faible valeur Y
                if (chk_centerBottom.Checked)   Y1_dxf -= DXF.Ymax; //  en bas = soustrait la plus forte valeur Y

                Rotate(X1_dxf, Y1_dxf, angle, out X1_dxf, out Y1_dxf);

                if ((X2_dxf != X1_dxf) || (Y2_dxf != Y1_dxf))
                {

                    // marqueur : stop
                    mymarker1 = new GMarkerGoogle(new PointLatLng(prevLat, prevLong), GMarkerGoogleType.red_small);
                    myText = "stop track ";
                    myText += NbrTrack.ToString();
                    mymarker1.ToolTipText = myText;
                    MapOverlay.Markers.Add(mymarker1);

                    //  trace cette partie du trajet
                    GMapRoute MapRoute = new GMapRoute(chemin, "Track " + NbrTrack.ToString()); // object for routing

                    MapRoute.IsHitTestVisible = true;

                    MapOverlay.Routes.Add(MapRoute);

                    Application.DoEvents();


                    //  nouveau chemin
                    chemin.Clear();

                    //  c'est une nouvelle track
                    NbrTrack++;

                    //  les coordonnées géographiques sur la carte
                    Xgeographic = XcentreMap + ((X1_dxf - XcentreDXF - DXF.Xmin) / diviseur);
                    Ygeographic = YcentreMap + ((Y1_dxf - YcentreDXF - DXF.Ymin) / diviseur);

                    // marqueur : start
                    mymarker1 = new GMarkerGoogle(new PointLatLng(Ygeographic, Xgeographic), GMarkerGoogleType.green_small);
                    myText = "start track ";
                    myText += NbrTrack.ToString();
                    mymarker1.ToolTipText = myText;
                    MapOverlay.Markers.Add(mymarker1);

                    chemin.Add(new PointLatLng(Ygeographic, Xgeographic));

                    dnewdistance = EarthDistanceCalc(prevLong, prevLat, Xgeographic, Ygeographic);
                    prevLong = Xgeographic; //  pour le prochain calcul de la distance
                    prevLat = Ygeographic;

                    //  les coordonnées pour pablo
                    Xtrack = (X1_dxf - XcentreDXF - DXF.Xmin) / diviseur;
                    Ytrack = (Y1_dxf - YcentreDXF - DXF.Ymin) / diviseur;

                    //  on s'y déplace sans tracer
                    Grid.Rows.Add(NbrTrack.ToString("0"), Math.Round(Ygeographic, 8).ToString("0.0000000"), Math.Round(Xgeographic, 8).ToString("0.0000000"), false, Math.Round(Ytrack, 8).ToString("+0.0000000;-0.0000000"), Math.Round(Xtrack, 8).ToString("+0.0000000;-0.0000000"), dnewdistance.ToString("##0.00"));
                    Grid.Rows[Grid.RowCount - 1].DefaultCellStyle.BackColor = Color.DarkGray;

                    Grid.Rows[Grid.RowCount - 1].HeaderCell.Value = NbrTrack.ToString();

                    //Grid.FirstDisplayedScrollingRowIndex = Grid.RowCount - 1;
                    Application.DoEvents();


                    //  fin du segment
                    X2_dxf = DXF.Vecteurs[i].x2;
                    Y2_dxf = DXF.Vecteurs[i].y2;

                    //  centrage
                    if (chk_centerLeft.Checked)     X2_dxf -= DXF.Xmin; //  à gauche = soustrait la plus faible valeur X
                    if (chk_centerRight.Checked)    X2_dxf -= DXF.Xmax; //  à droite = soustrait la plus forte valeur X

                    if (chk_centerTop.Checked)      Y2_dxf -= DXF.Ymin; //  en haut = soustrait la plus faible valeur Y
                    if (chk_centerBottom.Checked)   Y2_dxf -= DXF.Ymax; //  en bas = soustrait la plus forte valeur Y

                    
                    Rotate(X2_dxf, Y2_dxf, angle, out X2_dxf, out Y2_dxf);

                    // les coordonnées géographiques sur la carte
                    Xgeographic = XcentreMap + ((X2_dxf - XcentreDXF - DXF.Xmin) / diviseur);
                    Ygeographic = YcentreMap + ((Y2_dxf - YcentreDXF - DXF.Ymin) / diviseur);

                    chemin.Add(new PointLatLng(Ygeographic, Xgeographic));

                    dnewdistance = EarthDistanceCalc(prevLong, prevLat, Xgeographic, Ygeographic);
                    prevLong = Xgeographic; //  pour le prochain calcul de la distance
                    prevLat = Ygeographic;

                    //  les coordonnées pour pablo
                    Xtrack = (X2_dxf - XcentreDXF - DXF.Xmin) / diviseur;
                    Ytrack = (Y2_dxf - YcentreDXF - DXF.Ymin) / diviseur;

                    //  on trace
                    Grid.Rows.Add(NbrTrack.ToString("0"), Math.Round(Ygeographic, 8).ToString("0.0000000"), Math.Round(Xgeographic, 8).ToString("0.0000000"), true, Math.Round(Ytrack, 8).ToString("+0.0000000;-0.0000000"), Math.Round(Xtrack, 8).ToString("+0.0000000;-0.0000000"), dnewdistance.ToString("##0.00"));
                    if (dnewdistance <= 1)
                    {
                        Grid.Rows[Grid.RowCount - 1].DefaultCellStyle.BackColor = Color.Yellow;
                    }

                    lbl_overlays.Text = NbrTrack.ToString();

                }
                else
                {
                    //  c'est la suite du segment précédent

                    //  fin du segment
                    X2_dxf = DXF.Vecteurs[i].x2;
                    Y2_dxf = DXF.Vecteurs[i].y2;

                    //  centrage
                    if (chk_centerLeft.Checked)     X2_dxf -= DXF.Xmin; //  à gauche = soustrait la plus faible valeur X
                    if (chk_centerRight.Checked)    X2_dxf -= DXF.Xmax; //  à droite = soustrait la plus forte valeur X

                    if (chk_centerTop.Checked)      Y2_dxf -= DXF.Ymin; //  en haut = soustrait la plus faible valeur Y
                    if (chk_centerBottom.Checked)   Y2_dxf -= DXF.Ymax; //  en bas = soustrait la plus forte valeur Y
                    
                    Rotate(X2_dxf, Y2_dxf, angle, out X2_dxf, out Y2_dxf);

                    // les coordonnées géographiques sur la carte
                    Xgeographic = XcentreMap + ((X2_dxf - XcentreDXF - DXF.Xmin) / diviseur);
                    Ygeographic = YcentreMap + ((Y2_dxf - YcentreDXF - DXF.Ymin) / diviseur);

                    chemin.Add(new PointLatLng(Ygeographic, Xgeographic));

                    // distance ?
                    dnewdistance = EarthDistanceCalc(prevLong, prevLat, Xgeographic, Ygeographic);
                    prevLong = Xgeographic;
                    prevLat = Ygeographic;

                    //  les coordonnées pour pablo
                    Xtrack = (X2_dxf - XcentreDXF - DXF.Xmin) / diviseur;
                    Ytrack = (Y2_dxf - YcentreDXF - DXF.Ymin) / diviseur;

                    Grid.Rows.Add(NbrTrack.ToString("0"), Math.Round(Ygeographic, 8).ToString("0.0000000"), Math.Round(Xgeographic, 8).ToString("0.0000000"), true, Math.Round(Ytrack, 8).ToString("+0.0000000;-0.0000000"), Math.Round(Xtrack, 8).ToString("+0.0000000;-0.0000000"), dnewdistance.ToString("##0.00"));
                    if (dnewdistance <= 1)
                    {
                        Grid.Rows[Grid.RowCount - 1].DefaultCellStyle.BackColor = Color.Yellow;
                    }

                    Application.DoEvents();

                }

                Application.DoEvents();

            }

            //  tracer le dernier segment
            if (chemin.Count > 0)
            {
                // marqueur : stop
                mymarker1 = new GMarkerGoogle(new PointLatLng(prevLat, prevLong), GMarkerGoogleType.red_small);
                myText = "stop track ";
                myText += NbrTrack.ToString();
                mymarker1.ToolTipText = myText;
                MapOverlay.Markers.Add(mymarker1);

                //  trace cette partie du trajet
                GMapRoute MapRoute = new GMapRoute(chemin, "Track " + NbrTrack.ToString()); // object for routing
                MapRoute.IsHitTestVisible = true;

                MapOverlay.Routes.Add(MapRoute);

                chemin.Clear();

            }

            gmap.Overlays.Add(MapOverlay);

            gmap.ZoomAndCenterRoutes("MyMapOverlay");

            lbl_overlays.Text = NbrTrack.ToString();

        }



        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #endregion

        #region utils

        private void Rotate( double Xin, double Yin, int angle, out double Xout, out double Yout )
        {
            double angleRadian = Math.PI * (double)angle / 180;
            double sina = Math.Sin(angleRadian);
            double cosa = Math.Cos(angleRadian);
            Xout = Xin * cosa - Yin * sina;
            Yout = Xin * sina + Yin * cosa;
        }

        public double EarthDistanceCalc(double Long1, double Lat1, double Long2, double Lat2)
        {
            /*
            The Haversine formula according to Dr. Math.
            http://mathforum.org/library/drmath/view/51879.html

            dlon = lon2 - lon1
            dlat = lat2 - lat1
            a = (sin(dlat/2))^2 + cos(lat1) * cos(lat2) * (sin(dlon/2))^2
            c = 2 * atan2(sqrt(a), sqrt(1-a))
            d = R * c

            Where
            * dlon is the change in longitude
            * dlat is the change in latitude
            * c is the great circle distance in Radians.
            * R is the radius of a spherical Earth.
            * The locations of the two points in
            spherical coordinates (longitude and
            latitude) are lon1,lat1 and lon2, lat2.
            */
            double dDistance = Double.MinValue;
            double dLat1InRad = Lat1 * (Math.PI / 180.0);
            double dLong1InRad = Long1 * (Math.PI / 180.0);
            double dLat2InRad = Lat2 * (Math.PI / 180.0);
            double dLong2InRad = Long2 * (Math.PI / 180.0);

            double dLongitude = dLong2InRad - dLong1InRad;
            double dLatitude = dLat2InRad - dLat1InRad;

            // Intermediate result a.
            double a = Math.Pow(Math.Sin(dLatitude / 2.0), 2.0) +
            Math.Cos(dLat1InRad) * Math.Cos(dLat2InRad) *
            Math.Pow(Math.Sin(dLongitude / 2.0), 2.0);

            // Intermediate result c (great circle distance in Radians).
            double c = 2.0 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1.0 - a));

            // Distance.
            // const Double kEarthRadiusMiles = 3956.0;
            const Double kEarthRadiusKms = 6376.5;
            dDistance = kEarthRadiusKms * c;

            // resultat en m&#232;tres
            return dDistance * 1000;
        }

        #endregion

        private void Scrl_Diviseur_Scroll(object sender, ScrollEventArgs e)
        {
            diviseur = Scrl_Diviseur.Value;
            diviseur = diviseur * 100;
            lbl_Diviseur.Text = diviseur.ToString();
        }

        private void Scrl_Rotation_Scroll(object sender, ScrollEventArgs e)
        {
            angle = Scrl_Rotation.Value;
            lbl_Rotation.Text = angle.ToString();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            gmap.Overlays.Clear();
            gmap.Refresh();
            Application.DoEvents();
            lbl_overlays.Text = gmap.Overlays.Count.ToString();

            Grid.Rows.Clear();
            
        }

        private void btn_OutTrames_Click(object sender, EventArgs e)
        {

            if (sFileName==null)
            {
                return;
            }

            if (sFileName.Length < 5)
            {
                return;
            }


            string myFilename = Path.GetFileNameWithoutExtension(sFileName);
            string myDirectoryPath = Path.GetDirectoryName(sFileName);
            string myFile = myDirectoryPath + "\\" + myFilename;

            StreamWriter stream_klm = new StreamWriter(myFile + ".kml");    //  création du fichier.kml
            StreamWriter stream_txt = new StreamWriter(myFile + ".txt");    //  création du fichier.txt

            //  < kml xmlns = "http://earth.google.com/kml/2.0" >
            //  < Document >

            stream_klm.WriteLine("<kml xmlns = \"http://earth.google.com/kml/2.0\">");      //  <kml xmlns="http://earth.google.com/kml/2.0">
            stream_klm.WriteLine("<Document>");

            //  < Style id = "thickBlackLine" >
            //  < LineStyle >
            //  < color > 87000000 </ color >
            //  < width > 10 </ width >
            //  </ LineStyle >
            //  <PolyStyle>
            //  < color > 7f00ff00 </ color >
            //  </ PolyStyle >


            //  </ Style >

            stream_klm.WriteLine("<Style id = \"thickBlackLine\">");
            stream_klm.WriteLine("<LineStyle>");
            stream_klm.WriteLine("<color> 7fff0000 </color>");     //  aa bb gg rr  couleur bleue avec 50% d'opacité à une superposition
            stream_klm.WriteLine("<width> 4 </width>");
            stream_klm.WriteLine("</LineStyle>");

            stream_klm.WriteLine("<PolyStyle>");
            stream_klm.WriteLine("<color> 7f00ff00 </color>");
            stream_klm.WriteLine("</PolyStyle>");

            stream_klm.WriteLine("</Style>");


            //  </Folder>
            stream_klm.WriteLine("<Folder>");


            //  < Placemark >
            //  < name > start </ name >
            //  < description > Test Track 17 / 02 / 2017 11:12:20 </ description >

            stream_klm.WriteLine("<Placemark>");
            stream_klm.WriteLine("<name>start</name>");
            stream_klm.WriteLine("<description>Track for Pablo " + DateTime.Now + "</description>");


            //  < LookAt >
            //  < longitude > -122.0839597145766 </ longitude >
            //  < latitude > 37.42222904525232 </ latitude >
            //  < altitude > 0 </ altitude >
            //  < heading > -148.4122922628044 </ heading >
            //  < tilt > 40.5575073395506 </ tilt >
            //  < range > 500.6566641072245 </ range >
            //  </ LookAt >

            stream_klm.WriteLine("<LookAt>");
            stream_klm.Write("<longitude>");

            double longitude = Convert.ToDouble(Grid.Rows[0].Cells[5].Value);
            stream_klm.Write( ( _CentreLongitude + longitude).ToString("00.0000000", CultureInfo.InvariantCulture));
            stream_klm.WriteLine("</longitude>");
            stream_klm.Write("<latitude>");
            double latitude = Convert.ToDouble(Grid.Rows[0].Cells[4].Value);
            stream_klm.Write( (_CentreLatitude + latitude).ToString("00.0000000", CultureInfo.InvariantCulture));
            stream_klm.WriteLine("</latitude>");
            stream_klm.WriteLine("<altitude> 0 </altitude>");
            stream_klm.WriteLine("<heading> 90 </heading>");
            stream_klm.WriteLine("<tilt> 45 </tilt>");
            stream_klm.WriteLine("<range> 500 </range>");

            stream_klm.WriteLine("</LookAt>");


            //Put a mark at Longitutde and Latitude 

            stream_klm.WriteLine("<Point>");
            stream_klm.Write("<coordinates>");
            longitude = Convert.ToDouble(Grid.Rows[0].Cells[5].Value);
            stream_klm.Write((_CentreLongitude + longitude).ToString("00.0000000", CultureInfo.InvariantCulture));
            stream_klm.Write(",");
            latitude = Convert.ToDouble(Grid.Rows[0].Cells[4].Value);
            stream_klm.Write((_CentreLatitude + latitude).ToString("00.0000000", CultureInfo.InvariantCulture));
            stream_klm.Write(",0");
            stream_klm.WriteLine("</coordinates>");
            stream_klm.WriteLine("</Point>");
            stream_klm.WriteLine("</Placemark>");

            // Toute première coordonnée de la 1ère piste
            //  < Placemark >
            //  < name > 0000 </ name >
            //  < styleUrl >#thickBlackLine</styleUrl>

            //  < LineString >
            //  < coordinates >

            int iTrack = 1;

            stream_klm.WriteLine("<Placemark>");
            stream_klm.Write("<name>");
            stream_klm.Write(iTrack.ToString("0000"));
            stream_klm.WriteLine("</name>");
            stream_klm.WriteLine("<styleUrl >#thickBlackLine</styleUrl>");

            //  <description> ... 
            stream_klm.Write("<description>");
            stream_klm.Write("Track number ");
            stream_klm.Write(iTrack.ToString("0000"));
            stream_klm.WriteLine("</description>");

            stream_klm.WriteLine("<LineString>");

            stream_klm.WriteLine("<altitudeMode>relativeToGround</altitudeMode>");

            stream_klm.WriteLine("<coordinates>");

            longitude = Convert.ToDouble(Grid.Rows[0].Cells[5].Value);

            latitude = Convert.ToDouble(Grid.Rows[0].Cells[4].Value);

            string strKML = string.Empty;
            strKML = strKML + (_CentreLongitude + longitude).ToString("00.0000000", CultureInfo.InvariantCulture);
            strKML = strKML + ",";
            strKML = strKML + (_CentreLatitude + latitude).ToString("00.0000000", CultureInfo.InvariantCulture);
            strKML = strKML + ",0";
            stream_klm.WriteLine(strKML);

            //  Fichier Texte
            string strTXT = string.Empty;
            strTXT = strTXT + longitude.ToString("00.0000000", CultureInfo.InvariantCulture);
            strTXT = strTXT + ";";
            strTXT = strTXT + latitude.ToString("00.0000000", CultureInfo.InvariantCulture);
            strTXT = strTXT + ";0"; //  0 car pas de tracé
            stream_txt.WriteLine(strTXT);




            //< Placemark >
            //< name >0000</ name >
            //< LineString >
            //< coordinates >
            //-02.0586495617,48.4651912748,0

            //  à partir de la suivante et jusqu'à la dernière

            for ( int i=1; i< Grid.RowCount;i++)
            {

                bool TRACE_ON = (bool)Grid.Rows[i].Cells[3].Value;

                latitude = Convert.ToDouble(Grid.Rows[i].Cells[4].Value);
                longitude = Convert.ToDouble(Grid.Rows[i].Cells[5].Value);
                

                //  Fichier Texte
                strTXT = string.Empty;
                strTXT = strTXT + longitude.ToString("00.0000000", CultureInfo.InvariantCulture);
                strTXT = strTXT + ";";
                strTXT = strTXT + latitude.ToString("00.0000000", CultureInfo.InvariantCulture);
 

                if (TRACE_ON)
                {
                    //  Fichier Texte, on trace
                    strTXT = strTXT + ";1"; //  1 car tracé
                }
                else
                {
                    //  Fichier Texte, on ne trace pas
                    strTXT = strTXT + ";0"; //  0 car pas de tracé
                    

                    // début d'une nouvelle piste = fin de la trace en cours
                    stream_klm.WriteLine("</coordinates>");
                    stream_klm.WriteLine("</LineString>");
                    stream_klm.WriteLine("</Placemark>");

                    iTrack++; //    trace + 1

                    // début nouvelle trace
                    stream_klm.WriteLine("<Placemark>");
                    stream_klm.Write("<name>");
                    stream_klm.Write(iTrack.ToString("0000"));
                    stream_klm.WriteLine("</name>");

                    stream_klm.WriteLine("<styleUrl >#thickBlackLine</styleUrl>");

                    //  <description> ... 
                    stream_klm.Write("<description>");
                    stream_klm.Write("Track number ");
                    stream_klm.Write(iTrack.ToString("0000"));
                    stream_klm.WriteLine("</description>");

                    stream_klm.WriteLine("<LineString>");

                    stream_klm.WriteLine("<altitudeMode>relativeToGround</altitudeMode>");

                    stream_klm.WriteLine("<coordinates>");

                }

                //  Fichier Texte
                stream_txt.WriteLine(strTXT);

                strKML = string.Empty;
                strKML = strKML + (_CentreLongitude + longitude).ToString("00.0000000", CultureInfo.InvariantCulture);
                strKML = strKML + ",";
                strKML = strKML + (_CentreLatitude + latitude).ToString( "00.0000000" , CultureInfo.InvariantCulture );
                strKML = strKML + ",0";
                stream_klm.WriteLine(strKML);

            }

            //  </ Point >
            //  </ Placemark >
            //  </ Document >
            //  </ kml >
            stream_klm.WriteLine("</coordinates>");
            stream_klm.WriteLine("</LineString>");
            stream_klm.WriteLine("</Placemark>");


            stream_klm.WriteLine("<Placemark>");
            stream_klm.WriteLine("<name>stop</name>");
            stream_klm.WriteLine("<Point>");
            stream_klm.Write("<coordinates>");
            stream_klm.Write((_CentreLongitude + longitude).ToString("00.0000000", CultureInfo.InvariantCulture));
            stream_klm.Write(",");
            stream_klm.Write((_CentreLatitude + latitude).ToString("00.0000000", CultureInfo.InvariantCulture));
            stream_klm.Write(",0");
            stream_klm.WriteLine("</coordinates>");
            stream_klm.WriteLine("</Point>");
            stream_klm.WriteLine("</Placemark>");

            stream_klm.WriteLine("</Folder>");

            stream_klm.WriteLine("</Document>");
            stream_klm.WriteLine("</kml>");


            stream_klm.Close();
            
            //  Fichier Texte
            stream_txt.Close();

            Application.DoEvents();

            //  48,4436826425599    ->    48.44368264
            // -2,07436391183877    ->   -02.07436391

            //            decimal
            //            places   degrees distance
            //----------------------
            //0        1                111  km
            //1        0.1              11.1 km
            //2        0.01             1.11 km
            //3        0.001            111  m
            //4        0.0001           11.1 m
            //5        0.00001          1.11 m
            //6        0.000001         11.1 cm
            //7        0.0000001        1.11 cm
            //8        0.00000001       1.11 mm

        }

        private void Grid_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int column = e.ColumnIndex;
            int row = e.RowIndex;

            double longitude = Convert.ToDouble(Grid.Rows[row].Cells[2].Value);
            double latitude = Convert.ToDouble(Grid.Rows[row].Cells[1].Value);
            int  NbrTrack = Convert.ToInt32(Grid.Rows[row].Cells[0].Value);


            gmap.Position = new GMap.NET.PointLatLng(latitude, longitude);

            // Application.DoEvents();

            double trackDistance = gmap.Overlays[0].Routes[NbrTrack-1].Distance * 1000;
            lbl_track_distance2.Text = trackDistance.ToString("000.00m");


        }

        private void btn_Regen_Click(object sender, EventArgs e)
        {
            Grid.RowEnter -= new DataGridViewCellEventHandler(Grid_RowEnter);

           // OpenFileDXF(sFileName);

            DrawDXF();

            Grid.RowEnter += new DataGridViewCellEventHandler(Grid_RowEnter);
        }

        private void btn_try1_Click(object sender, EventArgs e)
        {
            Application.DoEvents();

            int Ioverlays = gmap.Overlays.Count;
            Console.Write("Overlays.Count : ");
            Console.WriteLine(Ioverlays.ToString("000"));

            for (int I=0; I< Ioverlays; I++)
            {
                int Iroutes = gmap.Overlays[I].Routes.Count;
 
                for (int J=0; J<Iroutes; J++)
                {
                    Console.WriteLine();

                    int Ipoints = gmap.Overlays[I].Routes[J].Points.Count;

                    for (int K=0; K<Ipoints; K++)
                    {

                        Console.Write("Overlay:");
                        Console.Write(I.ToString("000"));

                        Console.Write("  Route:");
                        Console.Write(J.ToString("000"));

                        Console.Write("  Distance:");
                        double trackDistance = gmap.Overlays[I].Routes[J].Distance * 1000;
                        Console.Write(trackDistance.ToString("000.00m"));

                        Console.Write("  Point:");
                        Console.Write(K.ToString("000  "));

                        Console.WriteLine( gmap.Overlays[I].Routes[J].Points[K].ToString()) ;

                    }

                }

            }

        }

        private void btn_Excentrer_Click(object sender, EventArgs e)
        {
 
            //  excentrer les coordonnées 
            //  coordonnées de la grille -> 

            Grid.RowEnter -= new DataGridViewCellEventHandler(Grid_RowEnter);


            double OffsetLongitude = 0;
            double OffsetLatitude = 0;


            if (_DessinCentreLongitude > _CentreLongitude) OffsetLongitude = -(_DessinCentreLongitude - _CentreLongitude);
            if (_DessinCentreLongitude < _CentreLongitude) OffsetLongitude = (_CentreLongitude - _DessinCentreLongitude);

            if (_DessinCentreLatitude > _CentreLatitude) OffsetLatitude = -(_DessinCentreLatitude - _CentreLatitude);
            if (_DessinCentreLatitude < _CentreLatitude) OffsetLatitude = (_CentreLatitude - _DessinCentreLatitude);


            double longitude;
            double latitude;


            //  à partir de la suivante et jusqu'à la dernière

            for (int i = 0; i < Grid.RowCount; i++)
            {

                latitude = Convert.ToDouble(Grid.Rows[i].Cells[1].Value);
                longitude = Convert.ToDouble(Grid.Rows[i].Cells[2].Value);

                latitude += OffsetLatitude;
                longitude += OffsetLongitude;

                Grid.Rows[i].Cells[1].Value = latitude.ToString("0.0000000");



            }






            Application.DoEvents();

            Grid.RowEnter += new DataGridViewCellEventHandler(Grid_RowEnter);

        }
    }

















    }




internal class cls_vecteur
{
    public double x1 { get; set; }
    public double y1 { get; set; }
    public double x2 { get; set; }
    public double y2 { get; set; }
}

